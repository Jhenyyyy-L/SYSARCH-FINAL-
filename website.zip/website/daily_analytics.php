<?php
include 'db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_analytics'])) {
    $selected_date = $_POST['selected_date'] ?? '';

    $query = "SELECT purpose, COUNT(*) AS count FROM reservations WHERE DATE(time_in) = ? GROUP BY purpose";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $selected_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $purposeData = [
        'labels' => [],
        'values' => [],
        'colors' => []
    ];
    while ($row = mysqli_fetch_assoc($result)) {
        $purposeData['labels'][] = $row['purpose'];
        $purposeData['values'][] = $row['count'];
        $purposeData['colors'][] = '#' . substr(md5(rand()), 0, 6);
    }

    $query = "SELECT lab_room, COUNT(*) AS count FROM reservations WHERE DATE(time_in) = ? GROUP BY lab_room";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $selected_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $labRoomData = [
        'labels' => [],
        'values' => [],
        'colors' => []
    ];
    while ($row = mysqli_fetch_assoc($result)) {
        $labRoomData['labels'][] = $row['lab_room'];
        $labRoomData['values'][] = $row['count'];
        $labRoomData['colors'][] = '#' . substr(md5(rand()), 0, 6);
    }

    $data = [
        'purposeData' => $purposeData,
        'labRoomData' => $labRoomData
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Analytics</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
*{
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.content {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .content h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .content form {
            margin-bottom: 20px;
        }
        .content form label {
            margin-right: 10px;
        }
        .content form input[type="date"] {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .content form button {
            padding: 10px 20px;
            border: none;
            background-color: #007bff;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .content form button:hover {
            background-color: #0056b3;
        }
        .chart {
            width: 400px;
            margin-bottom: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .back-button {
            padding: 10px 20px;
            border: none;
            background-color: #007bff;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 20px;
        }

        .back-button:hover {
            background-color: #0056b3;
        }
</style>
<div class="content">
    <h2>Daily Analytics</h2>
    <form method="POST" action="">
        <label for="selected_date" class="text-green-400">Select Date:</label>
        <input type="date" id="selected_date" name="selected_date" class="rounded-lg bg-gray-600 text-white px-2 py-1 h-10">

        <button type="submit" name="generate_analytics">Generate Analytics</button>
    </form>

    <?php if (isset($data)): ?>
        <div class="charts-container">
            <div class="chart">
                <canvas id="purposeChart"></canvas>
            </div>
            <div class="chart">
                <canvas id="labRoomChart"></canvas>
            </div>

            <button onclick="goToGenerateReports()" class="back-button">Go Back to Generate Reports</button>

        <script>
            function goToGenerateReports() {
                window.location.href = 'reports.php';
            }
        </script>

        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var data = <?php echo json_encode($data); ?>;

                function renderPieChart(data, chartId, label) {
                    var ctx = document.getElementById(chartId).getContext('2d');
                    new Chart(ctx, {
                        type: 'pie',
                        data: {
                            labels: data.labels,
                            datasets: [{
                                label: label,
                                data: data.values,
                                backgroundColor: data.colors,
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                        }
                    });
                }

                renderPieChart(data.purposeData, 'purposeChart', 'Purpose');
                renderPieChart(data.labRoomData, 'labRoomChart', 'Lab Room');
            });
        </script>
    <?php endif; ?>
</div>
</body>
</html>

<?php
$conn->close();
?>