<?php
session_start();
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $feedback_content = $_POST['feedback_content'];

    if (!empty($feedback_content)) {
        $sql = "INSERT INTO feedback (feedback_content) VALUES (?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $feedback_content);

        if ($stmt->execute()) {
            $_SESSION['feedback_message'] = "Feedback/Report successfully submitted!";
        } else {
            $_SESSION['feedback_message'] = "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['feedback_message'] = "Feedback content cannot be empty.";
    }
    
    header("Location: feedback_reports.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback and Reporting</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
* {
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.sidebar {
    background-color: black;
    color: white;
    width: 250px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 999;
}

.sidebar .logo {
    padding: 20px;
    text-align: center;
}

.sidebar .logo span {
    display: block;
    margin-top: 10px;
    font-size: 18px;
}

.sidebar .menu {
    padding: 0;
    margin: 0;
    list-style: none;
}

.sidebar .menu li {
    padding: 15px 20px;
    border-bottom: 1px solid #333;
}

.sidebar .menu li.active {
    background-color: #333;
}

.sidebar .menu li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.sidebar .menu li a i {
    margin-right: 10px;
}

.container {
    margin-left: 300px;
    margin-top: 300px;
    width: 50%;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.input {
    font-weight: 500;
    font-size: 14px;
    height: 40px;
    width: 200%;
    border-radius: 10px;
    padding-left: 10px;
    border: 1px solid black;
    outline: none;
    margin-top: 20px;
    text-decoration: none;
}

.input:focus {
    border-color: #6941c6;
    transition: border-color 0.5s;
}

.button {
    display: inline-block;
    border-radius: 4px;
    background-color: #3d405b;
    border: none;
    color: #FFFFFF;
    text-align: center;
    font-size: 12px;
    padding: 12px;
    width: 160px;
    transition: all 0.5s;
    cursor: pointer;
    margin-top: 20px;
}

.button span {
    cursor: pointer;
    display: inline-block;
    position: relative;
    transition: 0.5s;
}

.button span:after {
    content: '»';
    position: absolute;
    opacity: 0;
    top: 0;
    right: -15px;
    transition: 0.5s;
}

.button:hover span {
    padding-right: 15px;
}

.button:hover span:after {
    opacity: 1;
    right: 0;
}

a {
    color: inherit;
    text-decoration: none;
    cursor: pointer;
}

.message {
    margin-top: 20px;
    padding: 10px;
    width: 50%;
    text-align: center;
    color: red;
    font-weight: 300;
}
</style>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
        <li><a href="student_dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="edit_profile.php"><i class="fas fa-user"></i><span>Profile</span></a></li>
        <li><a href="remaining_sessions.php"><i class="fas fa-calendar-check"></i><span>View Remaining Session</span></a></li>
        <li><a href="sitin_history.php"><i class="fas fa-history"></i><span>Sitin Logs</span></a></li>
        <li class="active"><a href="feedback_reports.php"><i class="fa-solid fa-flag"></i><span>Feedback and Reporting</span></a></li>
        <li><a href="safety.php"><i class="fa-solid fa-user-shield"></i><span>Safety Monitoring/Alert</span></a></li>
        <li><a href="view_announcement.php"><i class="fa-solid fa-scroll"></i><span>View Announcement</span></a></li>
        <li><a href="future_reservation.php"><i class="fa-solid fa-bookmark"></i><span>Future Reservations</span></a></li>
        <li><a href="lab_rules.php"><i class="fa-solid fa-circle-info"></i><span>Lab Sitin Rules</span></a></li>
        <li class="logout"><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
</div>

<div class="container">
    <form method="post" action="feedback_reports.php">
        <input type="text" class="input" name="feedback_content" placeholder="Type feedback here..." required>
        <br>
        <button type="submit" class="button"><span>Submit Feedback</span></button>
    </form>
    <?php
    if (!empty($_SESSION['feedback_message'])) {
        echo "<div class='message'>" . $_SESSION['feedback_message'] . "</div>";
        unset($_SESSION['feedback_message']);
    }
    ?>
</div>
</body>
</html>