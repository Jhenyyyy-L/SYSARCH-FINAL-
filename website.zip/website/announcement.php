<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['announcement'])) {
    $announcement = $_POST['announcement'];
    $details = $_POST['details'];

    $sql = "INSERT INTO announcement (announcement, details) VALUES ('$announcement', '$details')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Announcement posted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql_delete = "DELETE FROM announcement WHERE id = $delete_id";
    if ($conn->query($sql_delete) === TRUE) {
        echo "Announcement deleted successfully.";
    } else {
        echo "Error: " . $sql_delete . "<br>" . $conn->error;
    }
}

$sql = "SELECT * FROM announcement ORDER BY created DESC";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Announcement</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
        *{
            margin: 0;
            padding: 0;
            border: none;
            outline: none;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            background-color: black;
            color: white;
            width: 250px;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
            z-index: 999;
        }

        .sidebar .logo {
            padding: 20px;
            text-align: center;
        }

        .sidebar .logo span {
            display: block;
            margin-top: 10px;
            font-size: 18px;
        }

        .sidebar .menu {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .sidebar .menu li {
            padding: 15px 20px;
            border-bottom: 1px solid #333;
        }

        .sidebar .menu li.active {
            background-color: #333;
        }

        .sidebar .menu li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .sidebar .menu li a i {
            margin-right: 10px;
        }

        h2{
            margin-left: 400px;
            margin-top: 150px;
        }

        .input {
            border-radius: 10px;
            outline: 2px solid black;
            border: 0;
            background-color: #e2e2e2;
            outline-offset: 3px;
            padding: 25px 1rem;
            transition: 0.25s;
            width: 100%;
            color: black; 
            max-width: 800px;
            margin-left: 400px;
            margin-top: 25px;
        }

        .input:focus {
            outline-offset: 5px;
            background-color: #fff
        }

        .button-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .button {
            position: relative;
            padding: 10px 22px;
            border-radius: 6px;
            border: none;
            color: #fff;
            cursor: pointer;
            background-color: black;
            transition: all 0.2s ease;
            margin-right: 950px;
        }

        .button:active {
            transform: scale(0.96);
        }

        .button:before,
        .button:after {
            position: absolute;
            content: "";
            width: 150%;
            left: 50%;
            height: 100%;
            transform: translateX(-50%);
            z-index: -1000;
            background-repeat: no-repeat;
        }

        .button:hover:before {
            top: -70%;
            background-image: radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                radial-gradient(circle, transparent 20%, #7d2ae8 20%, transparent 30%),
                radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                radial-gradient(circle, transparent 10%, #7d2ae8 15%, transparent 20%),
                radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                radial-gradient(circle, #7d2ae8 20%, transparent 20%);
            background-size: 10% 10%, 20% 20%, 15% 15%, 20% 20%, 18% 18%, 10% 10%, 15% 15%,
                10% 10%, 18% 18%;
            background-position: 50% 120%;
            animation: greentopBubbles 0.6s ease;
        }

        @keyframes greentopBubbles {
        0% {
            background-position: 5% 90%, 10% 90%, 10% 90%, 15% 90%, 25% 90%, 25% 90%,
            40% 90%, 55% 90%, 70% 90%;
        }

        50% {
            background-position: 0% 80%, 0% 20%, 10% 40%, 20% 0%, 30% 30%, 22% 50%,
            50% 50%, 65% 20%, 90% 30%;
        }

        100% {
            background-position: 0% 70%, 0% 10%, 10% 30%, 20% -10%, 30% 20%, 22% 40%,
            50% 40%, 65% 10%, 90% 20%;
            background-size: 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%;
        }
        }

        .button:hover::after {
                bottom: -70%;
                background-image: radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                    radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                    radial-gradient(circle, transparent 10%, #7d2ae8 15%, transparent 20%),
                    radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                    radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                    radial-gradient(circle, #7d2ae8 20%, transparent 20%),
                    radial-gradient(circle, #7d2ae8 20%, transparent 20%);
                background-size: 15% 15%, 20% 20%, 18% 18%, 20% 20%, 15% 15%, 20% 20%, 18% 18%;
                background-position: 50% 0%;
                animation: greenbottomBubbles 0.6s ease;
        }

        @keyframes greenbottomBubbles {
        0% {
            background-position: 10% -10%, 30% 10%, 55% -10%, 70% -10%, 85% -10%,
            70% -10%, 70% 0%;
        }

        50% {
            background-position: 0% 80%, 20% 80%, 45% 60%, 60% 100%, 75% 70%, 95% 60%,
            105% 0%;
        }

        100% {
            background-position: 0% 90%, 20% 90%, 45% 70%, 60% 110%, 75% 80%, 95% 70%,
            110% 10%;
            background-size: 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%;
        }
}

        input {
        width: 700px;
        height: 50px;
        padding: 0 14px;
        background:#e2e2e2;
        border-radius: 10px;
        border: 1px solid black;
        color: black; ;
        margin-top: 20px;
        margin-left: 395px;
        }

        input:valid {
        border-color: red;
        animation: none;
        }

        @keyframes shake_541 {
        0%, 100% {
            translate: 0;
        }

        25% {
            translate: 8px 0;
        }

        75% {
            translate: -8px 0;
        }
        }

        .announcements-container{
            margin-left: 300px;
}

.announcements-container {
    margin-left: 300px;
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    gap: 20px;
}

.card {
    overflow: hidden;
    position: relative;
    text-align: left;
    border-radius: 1rem;
    width: 280px;
    height: 180px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    background-color: none;
    border: 2px solid black;
}

.dismiss {
    position: absolute;
    right: 10px;
    top: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0.5rem 1rem;
    background-color: white;
    color: black;
    border: 2px solid #D1D5DB;
    font-size: 1rem;
    font-weight: 500;
    width: 30px;
    height: 30px;
    border-radius: 7px;
    transition: .3s ease;
}

.dismiss:hover {
    background-color: #ee0d0d;
    border: 2px solid #ee0d0d;
    color: #fff;
}

.header {
    padding: 1.25rem 1rem 1rem 1rem;
}

.content {
    text-align: center;
}

.title {
    color: black;
    font-size: .90rem;
    font-weight: 550;
    line-height: 1rem;
    text-decoration: underline;
}

.announce {
    margin-top: 0.5rem;
    color: black;
    font-size: 1rem;
    line-height: 2rem;
}

.details {
    margin-top: none;
    color: darkgray;
    font-size: .80rem;
    line-height: 2rem;
}

.created {
    margin-top: none;
    color: gray;
    font-size: .80rem;
    line-height: 2rem;
}

@keyframes animate {
    from {
        transform: scale(1);
    }

    to {
        transform: scale(1.09);
    }
}
</style>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
        <li><a href="#"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i><span>Search</span></a></li>
        <li><a href="delete.php"><i class="fas fa-trash"></i><span>Delete</span></a></li>
        <li><a href="resetpass.php"><i class="fa-solid fa-pen"></i><span>Reset Password</span></a></li>
        <li><a href="sit_in_records.php"><i class="fas fa-file"></i><span>View Sitin Records</span></a></li>
        <li><a href="reports.php"><i class="fas fa-book"></i><span>Generate Reports</span></a></li>
        <li class="active"><a href="announcement.php"><i class="fa-solid fa-bullhorn"></i><span>Post Announcement</span></a></li>
        <li><a href="approval.php"><i class="fa-solid fa-thumbs-up"></i><span>Booking Requests and Approval</span></a></li>
        <li><a href="view_f_r.php"><i class="fa-solid fa-flag"></i><span>View Feedback/Reports</span></a></li>
        <li class="logout"><a href="a_s_logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
</div>
<h2>Announcements:</h2>
<div class="container">
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <input type="text" placeholder="Type announcement here..." name="announcement" class="input" required>
        <br>
        <input type="text" placeholder="Enter details..." name="details" class="input">
        <div class="button-container">
            <button type="submit" class="button">Post Announcement</button>
        </div>
    </form>
</div>
<br>
<br>
<br>
<div class="announcements-container">
<?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo '<div class="card">';
            echo '<a href="?delete_id=' . $row['id'] . '" class="dismiss">×</a>'; // Link to delete announcement
            echo '<div class="header">';
            echo '</div>';
            echo '<div class="content">';
            echo '<span class="title">Announcement</span>';
            echo '<p class="announce">' . $row["announcement"] . '</p>';
            echo '<p class="details">' . $row["details"] . '</p>';
            echo '<p class="created">' . $row["created"] . '</p>';
            echo '</div>';
            echo '<div class="actions">';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "<p>No announcements yet.</p>";
    }
    ?>
</div>
</body>
</html>
