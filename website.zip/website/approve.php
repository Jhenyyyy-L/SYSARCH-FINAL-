<?php
include "db_config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $booking_id = $_POST['booking_id'];

    // Fetch the booking details
    $sql = "SELECT student_id, purpose, lab_room, pc_number, date_res, time_res FROM bookings WHERE id=?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
        $stmt->bind_result($student_id, $purpose, $lab_room, $pc_number, $date_res, $time_res);
        $stmt->fetch();
        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
        exit();
    }

    // Update the status of the booking to "approved"
    $sql = "UPDATE bookings SET status='approved' WHERE id=?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $booking_id);

        if ($stmt->execute()) {
            // Insert the booking details into the reservations table
            $insert_sql = "INSERT INTO reservations (student_id, purpose, lab_room) VALUES (?, ?, ?)";
            if ($insert_stmt = $conn->prepare($insert_sql)) {
                $insert_stmt->bind_param("sss", $student_id, $purpose, $lab_room);
                if ($insert_stmt->execute()) {
                    echo "Booking approved and added to reservations successfully.";
                } else {
                    echo "Error: " . $insert_stmt->error;
                }
                $insert_stmt->close();
            } else {
                echo "Error: " . $conn->error;
            }
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}

// Redirect back to the approval page
header("Location: approval.php");
exit();
?>
