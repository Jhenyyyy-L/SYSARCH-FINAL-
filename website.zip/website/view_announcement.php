<?php
include 'db_config.php';

$sql = "SELECT * FROM announcement ORDER BY created DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Announcement</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
* {
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.sidebar {
    background-color: black;
    color: white;
    width: 250px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 999;
}

.sidebar .logo {
    padding: 20px;
    text-align: center;
}

.sidebar .logo span {
    display: block;
    margin-top: 10px;
    font-size: 18px;
}

.sidebar .menu {
    padding: 0;
    margin: 0;
    list-style: none;
}

.sidebar .menu li {
    padding: 15px 20px;
    border-bottom: 1px solid #333;
}

.sidebar .menu li.active {
    background-color: #333;
}

.sidebar .menu li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.sidebar .menu li a i {
    margin-right: 10px;
}

h1 {
    text-align: center;
    font-size: 30px;
    margin-top: 20px;
}

.announcements-container {
    margin-left: 270px;
    padding: 18px;
}

table {
    width: 60%;
    margin: 0 auto;
    border-collapse: collapse;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 15px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
    font-weight: bold;
}

td {
    background-color: #fff;
}

td, th {
    text-decoration: none;
}

a {
    color: inherit;
    text-decoration: none;
    cursor: default;
}
</style>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
        <li><a href="student_dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="edit_profile.php"><i class="fas fa-user"></i><span>Profile</span></a></li>
        <li><a href="remaining_sessions.php"><i class="fas fa-calendar-check"></i><span>View Remaining Session</span></a></li>
        <li><a href="sitin_history.php"><i class="fas fa-history"></i><span>Sitin Logs</span></a></li>
        <li><a href="feedback_reports.php"><i class="fa-solid fa-flag"></i><span>Feedback and Reporting</span></a></li>
        <li><a href="safety.php"><i class="fa-solid fa-user-shield"></i><span>Safety Monitoring/Alert</span></a></li>
        <li class="active"><a href="view_announcement.php"><i class="fa-solid fa-scroll"></i><span>View Announcement</span></a></li>
        <li><a href="future_reservation.php"><i class="fa-solid fa-bookmark"></i><span>Future Reservations</span></a></li>
        <li><a href="lab_rules.php"><i class="fa-solid fa-circle-info"></i><span>Lab Sitin Rules</span></a></li>
        <li class="logout"><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
</div>

<div class="announcements-container">
    <h1>Announcements</h1>
    <table>
        <thead>
            <tr>
                <th>Announcement</th>
                <th>Details</th>
                <th>Created</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($row["announcement"]) . '</td>';
                    echo '<td>' . htmlspecialchars($row["details"]) . '</td>';
                    echo '<td>' . htmlspecialchars($row["created"]) . '</td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="3">No announcements yet.</td></tr>';
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
