<?php
include 'db_config.php';

$query = "SELECT purpose, COUNT(*) AS count FROM reservations GROUP BY purpose";
$result = mysqli_query($conn, $query);
$purposeData = [];
while ($row = mysqli_fetch_assoc($result)) {
    $purposeData['labels'][] = $row['purpose'];
    $purposeData['values'][] = $row['count'];
    $purposeData['colors'][] = '#'.substr(md5(rand()), 0, 6);
}

$query = "SELECT lab_room, COUNT(*) AS count FROM reservations GROUP BY lab_room";
$result = mysqli_query($conn, $query);
$labRoomData = [];
while ($row = mysqli_fetch_assoc($result)) {
    $labRoomData['labels'][] = $row['lab_room'];
    $labRoomData['values'][] = $row['count'];
    $labRoomData['colors'][] = '#'.substr(md5(rand()), 0, 6);
}

$data = [
    'purposeData' => $purposeData,
    'labRoomData' => $labRoomData
];

header('Content-Type: application/json');
echo json_encode($data);
?>