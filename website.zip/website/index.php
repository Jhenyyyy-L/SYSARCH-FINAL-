<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <style>
 @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            border: none;
            outline: none;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        .container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: linear-gradient(45deg, #3498db, #2ecc71);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: none;
            overflow: hidden;
            z-index: -1;
        }

        .container::before {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            background-image: linear-gradient(
                90deg,
                rgba(255, 255, 255, 0.1) 1px,
                transparent 1px
            ),
            linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px);
            background-size: 20px 20px;
            pointer-events: none;
        }

        h2, p {
            color: black;
        }

        section {
            position: relative;
            width: 100%;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            z-index: 1;
        }

        header {
            position: relative;
            top: 0;
            width: 100%;
            padding: 20px 100px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid black;
        }

        header .logo {
            width: 400px;
            height: auto;
            border-radius: 500px;
        }

        header .nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            letter-spacing: 1px;
            padding: 2px 18px;
            border-radius: 20px;
            transition: 0.3s;
            transition-property: background;
        }

        header .nav a:not(:last-child){
            margin-right: 30px;            
        }

        header .nav a:hover{
            background: gray;
        }

        .content{
            max-width: 650px;
            margin: 60px 100px;
        }

        .content .info h2{
            color: #35374B;
            font-size: 50px;
            text-transform: uppercase;
            font-weight: 800;
            letter-spacing: 2px;
            line-height: 60px;
            margin-bottom: 30px;

        }

        .content .info h2 span{
            color: #DEAC80;
            font-size: 35px;
            font-weight: 600;
        }

        .content .info p{
            font-size: 16px;
            font-weight: 800;
            margin-bottom: 40px;
        }

        .content .info-btn{
            color: white;
            background: black;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 2px;
            padding: 10px 20px;
            border-radius:5px;
            transition: 0.3s;
            transition-property: background;
        }

        .content .info-btn:hover{
            background: #35374B ;
        }

        footer{
            background-color: gray;
        }

        .footerContainer{
            width: 100%;
            padding: 70px 30px 20px;
        }

        .socialIcons{
            display:flex;
            justify-content: center;
        }

        .socialIcons a{
            text-decoration: none;
            padding: 10px;
            background-color: white;
            margin: 10px;
            border-radius: 50%;
        }

        .socialIcons a i{
            font-size: 2em;
            color: black;
            opacity: 0.9;
        }

        .footerBottom{
            color: white;
        }

        .bell {
            position: fixed;
            right: 300px;
            bottom: 100px;
            width: 580px;
            height: auto;
            z-index: 100;
        }
    </style>
</head>
<body>
<div class="container">
    <section>
        <header>
            <a href="#"><img src="logo.png" alt="Logo" class="logo"></a>
            <div class="nav">
                <a href="#">Home</a>
                <a href="#">About</a>
                <a href="#">Info</a>
                <a href="#">Services</a>
                <a href="#">Contact</a>
            </div>
        </header>
        <div class="line"></div>
        <br>
        <br>
        <div class="content">
            <div class="info">
                <h2>Seamless lab access, <br> at your fingertips.<br>
                    <span>Reserve your spot!</span>
                </h2>
                <br>
                <p>
                    Introducing the CCS Sit-In Monitoring System app, designed exclusively for students at the College of Computer Science. This innovative application streamlines the process of
                    reserving computer laboratory sessions with ease. Students can now effortlessly book specific time slots in advance, ensuring a seamless experience for accessing the resources they need.
                    With real-time updates on remaining session availability, students can plan their study sessions effectively. Say goodbye to waiting in queues or uncertainty about lab availability the
                    CCS Sit-In Monitoring System app puts control in the palm of your hand.
                </p>
                <br>
                <button class="info-btn" onclick="window.location.href='login1.php'">GET STARTED</button> 
            </div>
        </div>
    </section>
<div class="footerContainer">
    <div class="socialIcons">
        <a href=""><i class="fa-brands fa-facebook"></i></a>
        <a href=""><i class="fa-brands fa-instagram"></i></a>
        <a href=""><i class="fa-brands fa-twitter"></i></a>
        <a href=""><i class="fa-brands fa-google-plus"></i></a>
        <a href=""><i class="fa-brands fa-youtube"></i></a>
    </div>
<div class="footerBottom">
    <p>Copyright &copy;2024; Designed by <span class="designer">Lausa, Jheny</span></p>
</div>
</div>
<img src="bell.gif" alt="Bell" class="bell">
</div>

<script>
function applyTypingEffect(element, text, delay) {
    let i = 0;
    const type = () => {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, delay);
        }
    };
    type();
}

const cardParagraph = document.querySelector('.card p');
const originalText = cardParagraph.textContent;
cardParagraph.textContent = '';
applyTypingEffect(cardParagraph, originalText, 20);
</script>

</body>
</html>
