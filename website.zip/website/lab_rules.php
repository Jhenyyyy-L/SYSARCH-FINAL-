<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Sitin Rules</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
* {
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.sidebar {
    background-color: black;
    color: white;
    width: 250px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 999;
}

.sidebar .logo {
    padding: 20px;
    text-align: center;
}

.sidebar .logo span {
    display: block;
    margin-top: 10px;
    font-size: 18px;
}

.sidebar .menu {
    padding: 0;
    margin: 0;
    list-style: none;
}

.sidebar .menu li {
    padding: 15px 20px;
    border-bottom: 1px solid #333;
}

.sidebar .menu li.active {
    background-color: #333;
}

.sidebar .menu li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.sidebar .menu li a i {
    margin-right: 10px;
}

h1 {
    font-family: "Poppins", sans-serif;
    text-align: center;
    font-size: 50px;
}

.card {
    width: 1250px;
    height: 890px;
    margin: 0 auto;
    background-color: #24233b;
    border-radius: 8px;
    z-index: 1;
    box-shadow: 0px 10px 10px rgb(73, 70, 92);
    transition: 0.5s;
    margin-top: 15px;
    margin-right: 200px;
}

.card:hover {
    transform: translateY(-7px);
    box-shadow: 0px 10px 10px black;
}

.top {
    display: flex;
    align-items: center;
    padding-left: 10px;
}

.circle {
    padding: 0 4px;
}

.circle2 {
    display: inline-block;
    align-items: center;
    width: 10px;
    height: 10px;
    padding: 1px;
    border-radius: 5px;
}

.red {
    background-color: #ff605c;
}

.yellow {
    background-color: #ffbd44;
}

.green {
    background-color: #00ca4e;
}

.header {
    margin: 5px;
    margin-top: 5px;
    border-radius: 5px;
}

#title2 {
    color: white;
    padding-left: 50px;
    font-size: 15px;
}

.code-container {
    text-align: center;
}

#code {
    width: 1250px;
    height: 890px;
    resize: none;
    background-color: rgb(73, 70, 92);
    border-radius: 5px;
    border: none;
    color: white;
    padding: 10px;
}

#code:focus {
    outline: none !important;
}

a {
    color: inherit;
    text-decoration: none;
    cursor: default;
}
</style>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
        <li><a href="student_dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="edit_profile.php"><i class="fas fa-user"></i><span>Profile</span></a></li>
        <li><a href="remaining_sessions.php"><i class="fas fa-calendar-check"></i><span>View Remaining Session</span></a></li>
        <li><a href="sitin_history.php"><i class="fas fa-history"></i><span>Sitin Logs</span></a></li>
        <li><a href="feedback_reports.php"><i class="fa-solid fa-flag"></i><span>Feedback and Reporting</span></a></li>
        <li><a href="safety.php"><i class="fa-solid fa-user-shield"></i><span>Safety Monitoring/Alert</span></a></li>
        <li><a href="view_announcement.php"><i class="fa-solid fa-scroll"></i><span>View Announcement</span></a></li>
        <li><a href="future_reservation.php"><i class="fa-solid fa-bookmark"></i><span>Future Reservations</span></a></li>
        <li class="active"><a href="lab_rules.php"><i class="fa-solid fa-circle-info"></i><span>Lab Sitin Rules</span></a></li>
        <li class="logout"><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
</div>

<div class="card">
    <div class="header">
        <div class="top">
            <div class="circle">
                <span class="red circle2"></span>
            </div>
            <div class="circle">
                <span class="yellow circle2"></span>
            </div>
            <div class="circle">
                <span class="green circle2"></span>
            </div>
            <div class="title">
            </div>
        </div>
    </div>
    <div class="code-container">
        <textarea readonly="" name="code" id="code" class="area"></textarea>
    </div>
</div>

<script>
var text = `
University of Cebu
COLLEGE OF INFORMATION & COMPUTER STUDIES

LABORATORY RULES AND REGULATIONS

To avoid embarrassment and maintain camaraderie with your friends and superiors at our laboratories, please observe the following:

1. Maintain silence, proper decorum, and discipline inside the laboratory. Mobile phones, walkmans and other personal pieces of equipment must be switched off.

2. Games are not allowed inside the lab. This includes computer-related games, card games and other games that may disturb the operation of the lab.

3. Surfing the internet is allowed only with the permission of the instructor. Downloading and installing of software are strictly prohibited.

4. Getting access to other websites not related to the course (especially pronographic and illicit sites) is strictly prohibited.

5. Deleting computer files and changing the set-up of the computer is a major offense.

6. Observe computer time usage carefully. A fifteen-minute allowance is given for each use. Otherwise, the unit will be given to those who wish to "sit-in".

7. Observe proper decorum while inside the laboratory.
a. Do not get inside the lab unless the instructor is present.
b. All bags, knapsacks, and the likes must be deposited at the counter.
c. Follow the seating arrangement of your instructor.
d. At the end of class, all software programs must be closed.
e. Return all chairs to their proper places after using.

8. Chewing gum, eating, drinking, smoking, and other forms of vandalism are prohibited inside the lab.

9. Anyone causing a continual disturbance will be asked to leave the lab. Acts or gestures offensive to the members of the community, including public display of physical intimacy, are not tolerated.

10. Persons exhibiting hostile or threatening behavior such as yelling, swearing, or disregarding requests made by lab personnel will be asked to leave the lab.

11. For serious offense, the lab personnel may call the Civil Security Office (CSU) for assistance.

12. Any technical problem or difficulty must be addressed to the laboratory supervisor, student assistant or instructor immediately.


DISCIPLINARY ACTION

First Offense - The Head or the Dean or OIC recommends to the Guidance Center for a suspension from classes for each offender.

Second and Subsequent Offenses - A recommendation for heavier sanction will be endorsed to the Guidance Center.`;

var index = 0;
var speed = 3;
var typingArea = document.getElementById("code");

function type() {
    if (index < text.length) {
        typingArea.value += text.charAt(index);
        index++;
        setTimeout(type, speed);
    }
}

window.onload = function() {
    type();
};
</script>

</body>
</html>
