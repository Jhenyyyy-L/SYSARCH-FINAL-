<?php
include "db_config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $booking_id = $_POST['booking_id'];

    // Update the status of the booking to "declined"
    $sql = "UPDATE bookings SET status='declined' WHERE id=?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $booking_id);

        if ($stmt->execute()) {
            echo "Booking declined successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}

// Redirect back to the approval page
header("Location: approval.php");
exit();
?>
