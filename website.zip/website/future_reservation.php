<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require 'db_config.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['student_id'], $_POST['pc_number'], $_POST['date'], $_POST['time'], $_POST['purpose'], $_POST['lab_room'])) {
        $username = $_SESSION['username'];
        $student_id = $_POST['student_id'];
        $pc_number = $_POST['pc_number'];
        $date = $_POST['date'];
        $time = $_POST['time'];
        $purpose = $_POST['purpose'];
        $lab_room = $_POST['lab_room'];

        $sql = "INSERT INTO bookings (student_id, pc_number, purpose, lab_room, date_res, time_res) 
                VALUES (?,?,?,?,?,?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sissss", $student_id, $pc_number, $purpose, $lab_room, $date, $time);
            if ($stmt->execute()) {
                $message = "Reservation successfully made.";
            } else {
                $message = "Error: ". $stmt->error;
            }
            $stmt->close();
        } else {
            $message = "Error: ". $conn->error;
        }
    } else {
        $message = "Form data is missing.";
    }
} else {
    $message = "Invalid request method.";
}


 // Ensure this is the last operation on the connection

 // Display the message
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Future Reservations</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
* {
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.sidebar {
    background-color: black;
    color: white;
    width: 250px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 999;
}

.sidebar .logo {
    padding: 20px;
    text-align: center;
}

.sidebar .logo span {
    display: block;
    margin-top: 10px;
    font-size: 18px;
}

.sidebar .menu {
    padding: 0;
    margin: 0;
    list-style: none;
}

.sidebar .menu li {
    padding: 15px 20px;
    border-bottom: 1px solid #333;
}

.sidebar .menu li.active {
    background-color: #333;
}

.sidebar .menu li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.sidebar .menu li a i {
    margin-right: 10px;
}

h1 {
    font-family: "Poppins", sans-serif;
    text-align: center;
    font-size: 50px;
}

.content {
    margin-left: 250px;
    padding: 20px;
}

.content h1 {
    margin-bottom: 20px;
    font-size: 24px;
}

.content form {
    max-width: 400px;
    margin: 0 auto;
}

.content form label {
    display: block;
    margin-bottom: 10px;
}

.content form select,
.content form input[type="date"],
.content form input[type="time"],
.content form button {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

.content form button {
    background-color: #007bff;
    color: #fff;
    cursor: pointer;
}

.content form button:hover {
    background-color: #0056b3;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #f2f2f2;
    font-weight: bold;
}
</style>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
        <li><a href="student_dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="edit_profile.php"><i class="fas fa-user"></i><span>Profile</span></a></li>
        <li><a href="remaining_sessions.php"><i class="fas fa-calendar-check"></i><span>View Remaining Session</span></a></li>
        <li><a href="sitin_history.php"><i class="fas fa-history"></i><span>Sitin Logs</span></a></li>
        <li><a href="feedback_reports.php"><i class="fa-solid fa-flag"></i><span>Feedback and Reporting</span></a></li>
        <li><a href="safety.php"><i class="fa-solid fa-user-shield"></i><span>Safety Monitoring/Alert</span></a></li>
        <li><a href="view_announcement.php"><i class="fa-solid fa-scroll"></i><span>View Announcement</span></a></li>
        <li class="active"><a href="future_reservation.php"><i class="fa-solid fa-bookmark"></i><span>Future Reservations</span></a></li>
        <li><a href="lab_rules.php"><i class="fa-solid fa-circle-info"></i><span>Lab Sitin Rules</span></a></li>
        <li class="logout"><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
</div>

<div class="content">
    <h1>Future Reservations</h1>
    <form action="future_reservation.php" method="post">
        <label for="student_id">Student ID:</label>
        <input type="text" id="student_id" name="student_id" required>
        <br>
        <label for="pc_number">Select PC Number:</label>
        <select name="pc_number" id="pc_number" required>
            <?php for ($i = 43; $i <= 49; $i++): ?>
                <option value="<?= $i ?>">PC <?= $i ?></option>
            <?php endfor; ?>
        </select>
        <br>
        <label for="purpose">Purpose:</label>
        <select id="purpose" name="purpose" required>
            <option value="Java">Java</option>
            <option value="C++">C++</option>
            <option value="HTML">HTML</option>
            <option value="Python">Python</option>
            <option value="PHP">PHP</option>
            <option value="C">C</option>
        </select>
        <br>
        <label for="lab_room">Lab Room:</label>
        <select id="lab_room" name="lab_room" required>
    <option value="524">524</option>
    <option value="526">526</option>
    <option value="528">528</option>
    <option value="542">542</option>
    <option value="544">544</option>
    <option value="517">517</option>
</select>
<br>
<label for="date">Date:</label>
<input type="date" id="date" name="date" required>
<br>
<label for="time">Time:</label>
<input type="time" id="time" name="time" required>
<br>
<button type="submit">Reserve</button>
</form>

<?php if ($message): ?>
    <p><?= $message ?></p>
<?php endif; ?>

<?php
// Fetching and displaying bookings table
$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Bookings</h2>";
    echo "<table>";
    echo "<tr><th>Student ID</th><th>PC Number</th><th>Purpose</th><th>Lab Room</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["student_id"] . "</td><td>" . $row["pc_number"] . "</td><td>" . $row["purpose"] . "</td><td>" . $row["lab_room"] . "</td><td>" . $row["status"];
    }
    echo "</table>";
} else {
    echo "No bookings found.";
}
?>

</div>
</body>
</html>
