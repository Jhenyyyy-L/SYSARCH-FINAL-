<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Requests and Approval</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
*{
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.sidebar {
    background-color: black;
    color: white;
    width: 250px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 999;
}

.sidebar .logo {
    padding: 20px;
    text-align: center;
}

.sidebar .logo span {
    display: block;
    margin-top: 10px;
    font-size: 18px;
}

.sidebar .menu {
    padding: 0;
    margin: 0;
    list-style: none;
}

.sidebar .menu li {
    padding: 15px 20px;
    border-bottom: 1px solid #333;
}

.sidebar .menu li.active {
    background-color: #333;
}

.sidebar .menu li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.sidebar .menu li a i {
    margin-right: 10px;
}

.container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .content {
            width: 80%;
            max-width: 1200px;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .action-buttons button {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .approve-button {
            background-color: green;
            color: white;
        }
        
        .decline-button {
            background-color: red;
            color: white;
        }
</style>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
        <li><a href="#"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i><span>Search</span></a></li>
        <li><a href="delete.php"><i class="fas fa-trash"></i><span>Delete</span></a></li>
        <li><a href="resetpass.php"><i class="fa-solid fa-pen"></i><span>Reset Password</span></a></li>
        <li><a href="sit_in_records.php"><i class="fas fa-file"></i><span>View Sitin Records</span></a></li>
        <li><a href="reports.php"><i class="fas fa-book"></i><span>Generate Reports</span></a></li>
        <li><a href="announcement.php"><i class="fa-solid fa-bullhorn"></i><span>Post Announcement</span></a></li>
        <li class="active"><a href="approval.php"><i class="fa-solid fa-thumbs-up"></i><span>Booking Requests and Approval</span></a></li>
        <li><a href="view_f_r.php"><i class="fa-solid fa-flag"></i><span>View Feedback/Reports</span></a></li>
        <li class="logout"><a href="a_s_logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
</div>

<div class="container">
    <div class="content">
        <h1>Booking Requests and Approval</h1>
 <?php
        include "db_config.php";

        $sql = "SELECT id, student_id, purpose, lab_room, pc_number, status, date_res, time_res FROM bookings";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table border='1'>";
            echo "<thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Purpose</th>
                        <th>Lab Room</th>
                        <th>PC Number</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . htmlspecialchars($row["student_id"]) . "</td>
                        <td>" . htmlspecialchars($row["purpose"]) . "</td>
                        <td>" . htmlspecialchars($row["lab_room"]) . "</td>
                        <td>" . htmlspecialchars($row["pc_number"]) . "</td>
                        <td>" . htmlspecialchars($row["date_res"]) . "</td>
                        <td>" . htmlspecialchars($row["time_res"]) . "</td>
                        <td>" . htmlspecialchars($row["status"]) . "</td>
                        <td>
                            <form action='approve.php' method='post' style='display:inline-block;'>
                                <input type='hidden' name='booking_id' value='" . htmlspecialchars($row["id"]) . "'>
                                <button type='submit' name='approve' class='approve-button'>Approve</button>
                            </form>
                            <form action='decline.php' method='post' style='display:inline-block;'>
                                <input type='hidden' name='booking_id' value='" . htmlspecialchars($row["id"]) . "'>
                                <button type='submit' name='decline' class='decline-button'>Decline</button>
                            </form>
                        </td>
                      </tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "No booking requests found.";
        }
        $conn->close();
        ?>
    </div>
</div>

</body>
</html>
