<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $feedback_content = $_POST['feedback_content'];
    $sql = "INSERT INTO feedback (feedback_content) VALUES (?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $feedback_content);
    if ($stmt->execute()) {
        echo "Feedback submitted successfully.";
    } else {
        echo "Error: ". $conn->error;
    }
    $stmt->close();
}
?>