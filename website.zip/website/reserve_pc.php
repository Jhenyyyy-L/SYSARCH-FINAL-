<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require 'db_config.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['pc_number'], $_POST['date'], $_POST['time'], $_POST['purpose'], $_POST['lab_room'])) {
        $username = $_SESSION['username'];
        $pc_number = $_POST['pc_number'];
        $date = $_POST['date'];
        $time = $_POST['time'];
        $purpose = $_POST['purpose'];
        $lab_room = $_POST['lab_room'];

        // Prepare the SQL statement
        $sql = "INSERT INTO bookings (student_id, pc_number, purpose, lab_room, date_res, time_res) 
                VALUES ((SELECT student_id FROM users WHERE username = ?), ?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sissss", $username, $pc_number, $purpose, $lab_room, $date, $time);

            // Execute the statement
            if ($stmt->execute()) {
                $message = "Reservation successfully made.";
            } else {
                $message = "Error: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            $message = "Error: " . $conn->error;
        }
    } else {
        $message = "Form data is missing.";
    }
} else {
    $message = "Invalid request method.";
}

// Close the connection
$conn->close();
?>