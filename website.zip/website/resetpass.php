<?php
session_start();
include 'db_config.php';

if(isset($_POST['reset_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if($new_password === $confirm_password) {

        if(isset($_SESSION['searched_student_id'])) {
            $student_id = $_SESSION['searched_student_id'];

        $sql_update_password = "UPDATE users SET password = ? WHERE student_id = ?";
        $stmt_update_password = $conn->prepare($sql_update_password);
        $stmt_update_password->bind_param("si", $new_password, $student_id);

        if($stmt_update_password->execute()) {
            echo "<script>alert('Password reset successfully.');</script>";
        } else {
            echo "<script>alert('Failed to reset password. Please try again.');</script>";
        }

        $stmt_update_password->close();
        } else {
            echo "<script>alert('Error: Student ID not found.');</script>";
        }
    } else {
        echo "<script>alert('Passwords do not match. Please try again.');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin/Staff Dashboard</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
*{
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.sidebar {
    background-color: black;
    color: white;
    width: 250px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 999;
}

.sidebar .logo {
    padding: 20px;
    text-align: center;
}

.sidebar .logo span {
    display: block;
    margin-top: 10px;
    font-size: 18px;
}

.sidebar .menu {
    padding: 0;
    margin: 0;
    list-style: none;
}

.sidebar .menu li {
    padding: 15px 20px;
    border-bottom: 1px solid #333;
}

.sidebar .menu li.active {
    background-color: #333;
}

.sidebar .menu li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.sidebar .menu li a i {
    margin-right: 10px;
}

.container {
    margin-left: 850px;
    margin-top: 150px;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 45vh;
    width: 300px;
    padding: 15px;
    border: 2px solid black;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    background-color: #f9f9f9;
}

.form-group {
    margin-bottom: 15px;
    text-align: center;
}

.label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

.input {
    width: 100%;
    padding: 8px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 5px;
    text-align: center;
}

.submit {
    background-color: black;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    margin-top: 20px;
}

.submit:hover {
    background-color: #333;
}

.center {
    text-align: center;
}
</style>
<br>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
        <li><a href="#"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i><span>Search</span></a></li>
        <li><a href="delete.php"><i class="fas fa-trash"></i><span>Delete</span></a></li>
        <li class="active"><a href="resetpass.php"><i class="fa-solid fa-pen"></i><span>Reset Password</span></a></li>
        <li><a href="sit_in_records.php"><i class="fas fa-file"></i><span>View Sitin Records</span></a></li>
        <li><a href="reports.php"><i class="fas fa-book"></i><span>Generate Reports</span></a></li>
        <li><a href="announcement.php"><i class="fa-solid fa-bullhorn"></i><span>Post Announcement</span></a></li>
        <li><a href="approval.php"><i class="fa-solid fa-thumbs-up"></i><span>Booking Requests and Approval</span></a></li>
        <li><a href="view_f_r.php"><i class="fa-solid fa-flag"></i><span>View Feedback/Reports</span></a></li>
        <li class="logout"><a href="a_s_logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
</div>

<div class="container">
    <center>
        <h2>Reset Password</h2>
        <br>
        <form method="post" action="resetpass.php">
            <div class="form-group">
                <label class="label" for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" class="input" required>
            </div>
            <div class="form-group">
                <label class="label" for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" class="input" required>
            </div>
            <button type="submit" name="reset_password" class="submit">Reset Password</button>
        </form>
    </center>
</div>

</body>
</html>